WScript.Echo("\n\nDownloading from \"" + WScript.Arguments(0) + "\" ...");
var WinHttpReq = new ActiveXObject("WinHttp.WinHttpRequest.5.1");
WinHttpReq.Open("GET",WScript.Arguments(0),/*async*/false);
WinHttpReq.Send();
//WScript.Echo(WinHttpReq.ResponseText);

/*To save a binary file use this code instead of previous line*/
BinStream = new ActiveXObject("ADODB.Stream");
BinStream.Type = 1;
BinStream.Open();
BinStream.Write(WinHttpReq.ResponseBody);
var file = WScript.Arguments(0);
var output = file.substr(file.lastIndexOf('/')+1);
WScript.Echo("\nWriting to \"" + output + "\" ...");//'Writing to "' + output + '" ...');
BinStream.SaveToFile(output);